package infobite.must.eat.modal;

public class HomeRestaurentModel {

    String hr_namne;
    String hr_address;
    String hr_img;
    int hr_img1;

    public HomeRestaurentModel() {
    }

    public String getHr_namne() {
        return hr_namne;
    }

    public void setHr_namne(String hr_namne) {
        this.hr_namne = hr_namne;
    }

    public String getHr_address() {
        return hr_address;
    }

    public void setHr_address(String hr_address) {
        this.hr_address = hr_address;
    }

    public String getHr_img() {
        return hr_img;
    }

    public void setHr_img(String hr_img) {
        this.hr_img = hr_img;
    }

    public int getHr_img1() {
        return hr_img1;
    }

    public void setHr_img1(int hr_img1) {
        this.hr_img1 = hr_img1;
    }
}
