package infobite.must.eat.interfaces;

/**
 * Created by Natraj3 on 6/23/2017.
 */
public interface FragmentChangeListener {

    void onFragmentVisible(String fragmentTag);
}
