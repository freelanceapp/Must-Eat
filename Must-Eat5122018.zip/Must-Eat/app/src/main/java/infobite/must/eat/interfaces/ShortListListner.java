package infobite.must.eat.interfaces;

import java.util.List;

/**
 * Created by Natraj3 on 7/7/2017.
 */

public interface ShortListListner {

    void onShortListUpdated(List<String> likesArrayList);
}
