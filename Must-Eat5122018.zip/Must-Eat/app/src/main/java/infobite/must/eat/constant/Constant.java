package infobite.must.eat.constant;

/**
 * Created by Dell on 12/3/2018.
 */

public class Constant {

    public static final String Login_Fragment = "Login_Fragment";
    public static final String SignUp_Fragment = "SignUp_Fragment";
    public static final String ForgotPassword_Fragment = "ForgotPassword_Fragment";
    public static final String Verification_Fragment = "Verification_Fragment";
    public static final String Home_Fragment = "Home_Fragment";
    public static final String HistoryFragment = "HistoryFragment";
    public static final String NotificationFragment = "NotificationFragment";
    public static final String AccountFragment = "AccountFragment";
    public static final String RestaurentMenuFragment = "RestaurentMenuFragment";
    public static final String RestaurentAboutFragment = "RestaurentAboutFragment";
    public static final String RestaurentReviewFragment = "RestaurentReviewFragment";
    public static final String MenuListFragment = "MenuListFragment";

}
