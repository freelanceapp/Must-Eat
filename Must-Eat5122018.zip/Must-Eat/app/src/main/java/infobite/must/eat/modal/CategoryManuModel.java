package infobite.must.eat.modal;

public class CategoryManuModel {
   private String CategoryMenu;

    public CategoryManuModel() {
    }

    public String getCategoryMenu() {
        return CategoryMenu;
    }

    public void setCategoryMenu(String categoryMenu) {
        CategoryMenu = categoryMenu;
    }
}
