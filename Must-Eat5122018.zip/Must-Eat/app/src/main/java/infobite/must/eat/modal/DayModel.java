package infobite.must.eat.modal;

public class DayModel {
    private String day;
    private String time;

    public DayModel() {
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
