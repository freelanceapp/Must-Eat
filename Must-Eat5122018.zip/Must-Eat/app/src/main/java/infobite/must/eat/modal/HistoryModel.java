package infobite.must.eat.modal;

public class HistoryModel {
    String h_img;
    String h_name;
    String h_address;
    String h_orderid;
    String h_items;
    String h_total_price;
    String h_delivery_time;
    int h_img1;


    public HistoryModel() {
    }

    public String getH_img() {
        return h_img;
    }

    public void setH_img(String h_img) {
        this.h_img = h_img;
    }

    public String getH_name() {
        return h_name;
    }

    public void setH_name(String h_name) {
        this.h_name = h_name;
    }

    public String getH_address() {
        return h_address;
    }

    public void setH_address(String h_address) {
        this.h_address = h_address;
    }

    public String getH_orderid() {
        return h_orderid;
    }

    public void setH_orderid(String h_orderid) {
        this.h_orderid = h_orderid;
    }

    public String getH_items() {
        return h_items;
    }

    public void setH_items(String h_items) {
        this.h_items = h_items;
    }

    public String getH_total_price() {
        return h_total_price;
    }

    public void setH_total_price(String h_total_price) {
        this.h_total_price = h_total_price;
    }

    public String getH_delivery_time() {
        return h_delivery_time;
    }

    public void setH_delivery_time(String h_delivery_time) {
        this.h_delivery_time = h_delivery_time;
    }

    public int getH_img1() {
        return h_img1;
    }

    public void setH_img1(int h_img1) {
        this.h_img1 = h_img1;
    }
}
